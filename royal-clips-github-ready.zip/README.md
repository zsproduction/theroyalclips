# 👑 ROYAL CLIPS

Royal Clips is a mobile-first short-video social app prototype, ready to deploy as a static website with **GitHub Pages**.

## Included

- TikTok-style vertical video feed
- Like button
- Search
- Creator profile
- Video upload demo
- Monetization dashboard
- Creator eligibility:
  - 100 followers
  - 10,000 eligible views in the previous 3 months
- PWA / installable web app
- Royal Clips logo
- GitHub Pages compatible relative paths

## Publish on GitHub Pages

1. Create a new GitHub repository, for example `royal-clips`.
2. Upload **all files and folders inside this project**.
3. Make sure `index.html` is in the repository's main/root folder.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select your main branch and the **/(root)** folder.
7. Save.
8. GitHub will give you your website address.

## Important

This is a V1 frontend/PWA prototype. Browser localStorage is used for demo data, so different users/devices do NOT share accounts or videos yet.

A production Royal Clips service needs a backend for:
- User authentication
- Database
- Cloud video storage/CDN
- Real likes, follows and comments
- Video processing and moderation
- Notifications
- Admin dashboard
- Advertising integration
- Secure server-side creator revenue calculations
- Creator payouts

Do not calculate real money or payouts only in browser JavaScript.

## Advertising architecture

For the future production version:
- Website advertising can use an approved publisher setup such as Google AdSense.
- Mobile app advertising can use Google AdMob.
- Creator revenue should be recorded and calculated securely on the server.

## Local testing

You can open `index.html` for the basic interface, but PWA/service-worker features work properly when served through HTTP/HTTPS, such as GitHub Pages.
