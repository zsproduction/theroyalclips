const demoVideos = [
  {id:1,user:"@royalcreator",title:"Welcome to Royal Clips 👑",desc:"Watch, create and earn.",views:1250,liked:false},
  {id:2,user:"@travelking",title:"Amazing sunset ✨",desc:"A beautiful short clip.",views:820,liked:false},
  {id:3,user:"@foodqueen",title:"Quick recipe 🍔",desc:"Easy food in seconds.",views:1640,liked:false}
];

const state = JSON.parse(localStorage.getItem("royalClipsState") || "null") || {
  followers:0, views3m:0, monthlyViews:0, earnings:0, balance:0, following:0, likes:0, name:"Royal Creator", customVideos:[]
};

const $ = id => document.getElementById(id);
const save = () => localStorage.setItem("royalClipsState", JSON.stringify(state));
const toast = msg => { const t=$("toast"); t.textContent=msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),2200); };

function renderFeed(){
  const list=[...demoVideos,...state.customVideos];
  $("videoFeed").innerHTML=list.map(v=>`
    <article class="video-card">
      <div class="placeholder-video"></div>
      <div class="video-overlay"></div>
      <div class="video-info"><h3>${escapeHtml(v.title)}</h3><p>${escapeHtml(v.user)} • ${Number(v.views||0).toLocaleString()} views<br>${escapeHtml(v.desc||"")}</p></div>
      <div class="actions">
        <button class="action ${v.liked?"liked":""}" onclick="likeVideo(${v.id})">♥</button>
        <button class="action" onclick="toast('Comments screen will connect to the backend in V2.')">💬</button>
        <button class="action" onclick="navigator.clipboard?.writeText(location.href);toast('Clip link copied!')">↗</button>
      </div>
    </article>`).join("");
}
window.likeVideo=id=>{
  const all=[...demoVideos,...state.customVideos], v=all.find(x=>x.id===id); if(!v)return;
  v.liked=!v.liked; state.likes += v.liked?1:-1; save(); renderFeed(); renderStats();
};
function renderStats(){
  const eligible=state.followers>=100 && state.views3m>=10000;
  $("followersText").textContent=state.followers.toLocaleString();
  $("viewsText").textContent=state.views3m.toLocaleString();
  $("followersBar").style.width=Math.min(100,state.followers)+"%";
  $("viewsBar").style.width=Math.min(100,state.views3m/100)+"%";
  $("statusText").textContent=eligible?"Eligible":"Not Eligible";
  $("earnings").textContent="$"+Number(state.earnings).toFixed(2);
  $("balance").textContent="$"+Number(state.balance).toFixed(2);
  $("monthlyViews").textContent=state.monthlyViews.toLocaleString();
  $("followersStat").textContent=state.followers.toLocaleString();
  $("pFollowers").textContent=state.followers.toLocaleString();
  $("pFollowing").textContent=state.following.toLocaleString();
  $("pLikes").textContent=state.likes.toLocaleString();
  $("profileName").textContent=state.name;
}
function showScreen(id){
  document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.remove("active"));
  $(id).classList.add("active");
  const nav=document.querySelector(`[data-screen="${id}"]`); if(nav)nav.classList.add("active");
  if(id==="earn")renderStats();
}
document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>showScreen(btn.dataset.screen)));
$("profileBtn").onclick=()=>showScreen("profile");

$("videoPicker").addEventListener("change",e=>{
  const file=e.target.files[0]; if(!file)return;
  const url=URL.createObjectURL(file);
  $("uploadPreview").innerHTML=`<video controls style="width:100%;max-height:360px;border-radius:16px;margin-bottom:12px" src="${url}"></video>`;
  $("publishBtn").disabled=false;
  $("publishBtn").dataset.name=file.name;
  $("publishBtn").dataset.url=url;
});
$("publishBtn").onclick=()=>{
  const title=$("publishBtn").dataset.name||"My Royal Clip";
  state.customVideos.unshift({id:Date.now(),user:"@"+state.name.toLowerCase().replace(/\s+/g,""),title,desc:"New Royal Clips video",views:0,liked:false});
  save(); renderFeed(); toast("Clip published in this demo!"); showScreen("feed");
};
$("demoProgress").onclick=()=>{
  state.followers+=10; state.views3m+=500; state.monthlyViews+=500; save(); renderStats(); toast("Demo progress added.");
};
$("editProfile").onclick=()=>{
  const n=prompt("Enter your creator name:",state.name); if(n){state.name=n.trim();save();renderStats();toast("Profile updated.");}
};
$("searchInput").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase();
  const all=[...demoVideos,...state.customVideos].filter(v=>(v.title+" "+v.user+" "+v.desc).toLowerCase().includes(q));
  $("searchResults").innerHTML=all.map(v=>`<div class="search-result"><b>${escapeHtml(v.title)}</b><div style="color:#999">${escapeHtml(v.user)} • ${v.views} views</div></div>`).join("") || `<p style="color:#888">No results yet.</p>`;
});
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

let deferredPrompt;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").hidden=false;});
$("installBtn").onclick=async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").hidden=true;};

renderFeed(); renderStats();
